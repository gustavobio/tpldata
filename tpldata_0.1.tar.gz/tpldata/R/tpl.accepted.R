#' The Plant List
#'
#' A few datasets containing data scraped from theplantlist.com
#' 
#' @docType data
#' @format Lists and data frames
#' @name tpl.accepted
#' @aliases tpl.misapplied tpl.names tpl.synonyms, tpl.unresolved, words, tpl.accepted.index
NULL