#' Package tpldata
#' 
#' The Plant List data
#' 
#' This package contains data from The Plant List database v1.1
#' 
#' @docType package
#' @name tpldata
#' @aliases tpldata tpldata-package
NULL